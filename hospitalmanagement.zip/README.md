# Medcare
<p style="text-align: justify;"  align="center">Create a complete responsive hospital / medical store / medical website design template using html css and vanilla javascript.</p>


![download](https://user-images.githubusercontent.com/71099757/131668021-9e24f2e9-c554-43a9-b4e1-c97a3e102439.png)

<p style="font-size:50rem;" align="center" >Full Web Page</p>

![Web capture_1-9-2021_18047_medcare-hospital netlify app](https://user-images.githubusercontent.com/71099757/131667998-dd8a1a92-1373-4d29-b3ee-8260a4bb6a1e.jpeg)


<p style="text-align: justify;" align="center">The main feature of this website are:

✔ responsive header section using flexbox.

✔ responsive home section using css flexbox.

✔ responsive count box section using css grid.

✔ responsive services box section using css grid.

✔ responsive about section using css flexbox.

✔ responsive team card section using css grid.

✔ responsive contact / booking form section using css flexbox.

✔ responsive testimonial / review card section using css grid.

✔ responsive blogs / post / news box section using css grid.

✔ responsive footer section using css grid.</p>

<p align="center" >If you like it than don't forget to hit the APPRECIATE button also!</p>

<p align="center" >Show some ❤️ by starring some of the repositories!</p>

